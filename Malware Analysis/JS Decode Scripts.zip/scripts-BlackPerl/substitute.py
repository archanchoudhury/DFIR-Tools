#!/usr/bin/env python3

import sys

if len(sys.argv) == 2:
	f = open(sys.argv[1], "r")
else:
	f = sys.stdin

assignDict = {}
lines = f.readlines()
for line in lines:
	line = line.strip()
	if "=" in line:
		parts = line.split("=")
		if len(parts) > 1:
			lhs = parts[0]
			rhs = "=".join(parts[1:])
			assignDict[lhs] = rhs[:-1]

for line in lines:
	newline = line
	for lhs, rhs in assignDict.items():
		if lhs in newline:
			newline = newline.replace(lhs, rhs)
	print(newline)
