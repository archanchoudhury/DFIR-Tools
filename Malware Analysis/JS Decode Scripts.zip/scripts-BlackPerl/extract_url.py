#!/usr/bin/env python3

import sys
from urllib.parse import unquote

text='\n'.join(sys.stdin.readlines())
print(unquote(text))
