#!/usr/bin/env python3

import sys

#print(sys.argv)
if len(sys.argv) > 1:
	f = open(sys.argv[1], "r")
else:
	f = sys.stdin

t = "".join(f.readlines())
i = 0
result = ""
while 1:
	if i >= len(t):
		break

	c = t[i]
	if c == '\\':
		i += 1
		c = t[i]
		# unicode sequence
		if c == 'u':
			x = int(t[i+1:i+5], 16)
#			print(x)
			try:
				result += chr(x)
			except:
				print("invalid unicode: {}".format(x), file=sys.stderr)
			i += 5
		# backslash hex 
		elif c == 'x':
			x = int(t[i+1:i+3], 16)
#			print(x)
			try:
				result += chr(x)
			except:
				print("invalid hex: {}".format(x), file=sys.stderr)
			i += 3
		# octal
		elif c in "01234567":
			n = ""
			while t[i] in "01234567":
				n += t[i]
				i += 1
#			print(n)
			val = int(n, 8)
			# if the number is too large to fit in a byte
			# just use the 1st 2 digits as the value and the rest of the
			# string is treated as characters.
			if val > 255:
				val = int(n[:2], 8)
				result += chr(val)
				result += n[2:]
			else:
				try:
					result += chr(val)
				except:
					print("invalid octal: {}".format(n), file=sys.stderr)
		else:
			result += c
			i += 1
	else:
		result += c
		i += 1

print(result)
